const accessCode1 = "VARIABLE";
const accessCode2 = "FUNCTION";
const accessCode3 = "DATABASE";

function clues() {
    
    fill("white")
    textSize(15)
    text("R E V B A I L A", 100,50)
    fill("lightblue")
    text("Hint: Always changing, not constant !!", 100,70)
// add code for displaying rest of the names and the hints.
    

}